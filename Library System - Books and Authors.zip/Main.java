public class Main {
    public static void main(String[] args) {
        // Create an Author object
        Author author = new Author("F. Scott Fitzgerald", "fscott.fitzgerald@example.com", "American");

        // Create a Book object and associate it with the Author object
        Book book = new Book("The Great Gatsby", 14.99, author);

        // Print the details of the Book, including the Author's information
        System.out.println(book.toString());
    }
}
